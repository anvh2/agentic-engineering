import { appendFile, mkdir, readFile, rename, writeFile } from 'node:fs/promises';
import { join } from 'node:path';
import { z } from 'zod';
import { runControlledCommand } from '../tools/execution-tools.ts';
import { delegationRequestSchema, restoreWorkingTree, routeTask, validateJsVerification, type DelegationRequest } from './delegation.ts';
import { gitStatusEntries, inspectChange, type ChangeFinding } from './change-review.ts';

/**
 * M4 sequential Engineering Lead loop. It plans, orders, gates, reviews, persists and resumes. It contains NO coding,
 * verification or retry logic: every coding task goes through routeTask() and the injected `delegate` (production:
 * the Mastra `coding-task-workflow`, i.e. executeDelegation -> runCodingTask), which stays the single authority.
 *
 *   plan -> [pick ready task -> gate -> delegate -> harness verdict -> deterministic change review] ->
 *   Claude review (accept | reject) -> next ready task -> ... -> integration verification
 *
 * One task at a time, max 5 delegated tasks per batch, no parallelism, no commits, no pushes.
 */

export const MAX_DELEGATED_PER_BATCH = 5;

export const TASK_STATUSES = [
  'PENDING',
  'RUNNING',
  'WORKER_PASS', // harness verified + deterministic review clean; waiting for the Lead's review
  'ACCEPTED',
  'REVIEW_REJECTED',
  'VERIFICATION_FAILED',
  'RUNTIME_FAILURE',
  'ESCALATED_TO_CLAUDE',
  'KEPT_BY_CLAUDE',
  'BLOCKED_BY_DEPENDENCY',
] as const;
export type TaskStatus = (typeof TASK_STATUSES)[number];

const FAILED_STATUSES: TaskStatus[] = ['REVIEW_REJECTED', 'VERIFICATION_FAILED', 'RUNTIME_FAILURE', 'ESCALATED_TO_CLAUDE', 'BLOCKED_BY_DEPENDENCY'];

export const batchTaskSchema = z.object({
  id: z.string().min(1),
  title: z.string().min(1),
  /** 'implementation' tasks count in the Local Worker Implementation Rate; anything else never does. */
  kind: z.enum(['implementation', 'planning', 'review']).default('implementation'),
  dependsOn: z.array(z.string()).default([]),
  executor: z.enum(['qwen', 'claude']),
  /** Required for qwen tasks: the full CodingTask contract + the Lead's honest assessment. */
  request: delegationRequestSchema.optional(),
  /** Required for claude tasks: why this is not delegable. */
  keptReason: z.string().optional(),
  expectedOutput: z.string().min(1),
  correctionOf: z.string().optional(),
});
export type BatchTaskPlan = z.input<typeof batchTaskSchema>;

export const batchPlanSchema = z.object({
  batchId: z.string().regex(/^[A-Za-z0-9._-]+$/),
  repository: z.string().min(1),
  description: z.string().min(1),
  maxDelegated: z.number().int().min(1).max(MAX_DELEGATED_PER_BATCH).default(MAX_DELEGATED_PER_BATCH),
  /** argv arrays run after every task is accepted (jest shape enforced like worker verification, or `go`). */
  integrationCommands: z.array(z.array(z.string()).min(1)).default([]),
  tasks: z.array(batchTaskSchema).min(1),
});
export type BatchPlan = z.input<typeof batchPlanSchema>;

export interface DelegationRecord {
  n: number;
  runId?: string;
  studioUrl?: string;
  startedAt: string;
  finishedAt?: string;
  engineeringStatus?: string;
  codingAttempts: number;
  runtimeRetries: number;
  durationMs: number;
  artifactDir?: string;
  verifier?: { command: string[]; exitCode: number | null } | null;
  reasons: string[];
  error?: string;
  /** Set when this infra-aborted delegation was re-queued (once per task). */
  requeued?: boolean;
}

export interface TaskState extends z.output<typeof batchTaskSchema> {
  status: TaskStatus;
  statusReason?: string;
  delegations: DelegationRecord[];
  statusBefore?: string[];
  findings: ChangeFinding[];
  /** Final diff of the allowed files (kept for review; also in the run artifact dir). */
  diff?: string;
  implementedBy?: 'qwen' | 'claude';
  review?: { decision: 'accept' | 'reject'; reason: string; by: string; at: string };
  supersededBy?: string;
}

export interface BatchState {
  batchId: string;
  repository: string;
  description: string;
  maxDelegated: number;
  integrationCommands: string[][];
  createdAt: string;
  updatedAt: string;
  state: 'READY' | 'AWAITING_REVIEW' | 'STOPPED' | 'COMPLETE' | 'VERIFICATION_FAILED';
  stopReason?: string;
  delegatedCount: number;
  tasks: TaskState[];
  integration?: { ok: boolean; at: string; results: { command: string[]; exitCode: number | null; output: string }[] };
}

export interface DelegationOutcome {
  runId?: string;
  studioUrl?: string;
  /** The workflow's result (status PASS | ESCALATED_TO_CLAUDE | RUNTIME_FAILURE | KEPT_BY_CLAUDE, attempts, diff, ...). */
  result?: {
    status: 'PASS' | 'ESCALATED_TO_CLAUDE' | 'RUNTIME_FAILURE' | 'KEPT_BY_CLAUDE';
    reasons: string[];
    codingAttempts: number;
    runtimeRetries: number;
    restored: boolean;
    artifactDir?: string;
    verifier?: { command: string[]; exitCode: number | null } | null;
  };
  /** Set when the workflow run itself could not start/finish (infrastructure, not a coding failure). */
  error?: string;
}

export interface DelegationHooks {
  /** Called as soon as the Mastra run exists, so its id is persisted even if the process or the server dies mid-run. */
  onStart(info: { runId: string; studioUrl?: string }): Promise<void>;
}

export interface BatchDeps {
  delegate(request: DelegationRequest, repository: string, hooks: DelegationHooks): Promise<DelegationOutcome>;
  now?: () => Date;
  log?: (line: string) => void;
}

// ---- persistence ----------------------------------------------------------------

export function batchDir(root: string, batchId: string): string {
  return join(root, batchId);
}

export async function saveBatch(root: string, state: BatchState): Promise<void> {
  const dir = batchDir(root, state.batchId);
  await mkdir(dir, { recursive: true });
  state.updatedAt = new Date().toISOString();
  const tmp = join(dir, 'batch.json.tmp');
  await writeFile(tmp, JSON.stringify(state, null, 2));
  await rename(tmp, join(dir, 'batch.json')); // atomic: a crash never leaves half a state file
}

export async function loadBatch(root: string, batchId: string): Promise<BatchState> {
  return JSON.parse(await readFile(join(batchDir(root, batchId), 'batch.json'), 'utf8')) as BatchState;
}

/** Append-only history: every transition is kept, so failure history survives resumes and corrections. */
async function logEvent(root: string, batchId: string, event: Record<string, unknown>): Promise<void> {
  await mkdir(batchDir(root, batchId), { recursive: true });
  await appendFile(join(batchDir(root, batchId), 'events.jsonl'), `${JSON.stringify({ ts: new Date().toISOString(), ...event })}\n`);
}

// ---- planning --------------------------------------------------------------------

export function createBatch(planInput: BatchPlan): BatchState {
  const plan = batchPlanSchema.parse(planInput);
  const ids = new Set<string>();
  for (const t of plan.tasks) {
    if (ids.has(t.id)) throw new Error(`duplicate task id ${t.id}`);
    ids.add(t.id);
  }
  for (const t of plan.tasks) {
    for (const d of t.dependsOn) if (!ids.has(d)) throw new Error(`${t.id} depends on unknown task ${d}`);
    if (t.executor === 'qwen' && !t.request) throw new Error(`${t.id}: a qwen task needs a delegation request`);
    if (t.executor === 'claude' && !t.keptReason?.trim()) throw new Error(`${t.id}: a task kept by Claude must record why`);
  }
  assertAcyclic(plan.tasks);
  const delegable = plan.tasks.filter((t) => t.executor === 'qwen').length;
  if (delegable > plan.maxDelegated) throw new Error(`${delegable} qwen tasks planned but the batch limit is ${plan.maxDelegated}`);
  for (const command of plan.integrationCommands) {
    if (command[0] !== 'npx' && command[0] !== 'go') throw new Error(`integration command "${command.join(' ')}" must start with npx (jest) or go`);
  }
  const now = new Date().toISOString();
  return {
    batchId: plan.batchId,
    repository: plan.repository,
    description: plan.description,
    maxDelegated: plan.maxDelegated,
    integrationCommands: plan.integrationCommands,
    createdAt: now,
    updatedAt: now,
    state: 'READY',
    delegatedCount: 0,
    tasks: plan.tasks.map((t) => ({
      ...t,
      status: t.executor === 'claude' ? 'KEPT_BY_CLAUDE' : 'PENDING',
      statusReason: t.executor === 'claude' ? t.keptReason : undefined,
      delegations: [],
      findings: [],
    })),
  };
}

function assertAcyclic(tasks: z.output<typeof batchTaskSchema>[]): void {
  const byId = new Map(tasks.map((t) => [t.id, t]));
  const visiting = new Set<string>();
  const done = new Set<string>();
  const visit = (id: string): void => {
    if (done.has(id)) return;
    if (visiting.has(id)) throw new Error(`dependency cycle through ${id}`);
    visiting.add(id);
    for (const d of byId.get(id)!.dependsOn) visit(d);
    visiting.delete(id);
    done.add(id);
  };
  for (const t of tasks) visit(t.id);
}

// ---- dependency logic --------------------------------------------------------------

const byId = (state: BatchState, id: string) => state.tasks.find((t) => t.id === id)!;

/** A rejected task replaced by a correction is judged by its correction. */
function effective(state: BatchState, task: TaskState): TaskState {
  let t = task;
  while (t.supersededBy) t = byId(state, t.supersededBy);
  return t;
}

export function isReady(state: BatchState, task: TaskState): boolean {
  return task.status === 'PENDING' && task.executor === 'qwen' && task.dependsOn.every((d) => effective(state, byId(state, d)).status === 'ACCEPTED');
}

/** Marks PENDING tasks whose dependency can no longer be satisfied. Returns the ids newly blocked. */
export function propagateBlocked(state: BatchState): string[] {
  const blocked: string[] = [];
  let changed = true;
  while (changed) {
    changed = false;
    for (const t of state.tasks) {
      if (t.status !== 'PENDING') continue;
      const bad = t.dependsOn.map((d) => effective(state, byId(state, d))).find((d) => FAILED_STATUSES.includes(d.status));
      if (bad) {
        t.status = 'BLOCKED_BY_DEPENDENCY';
        t.statusReason = `dependency ${bad.id} is ${bad.status}`;
        blocked.push(t.id);
        changed = true;
      }
    }
  }
  return blocked;
}


/**
 * Resume: a task left RUNNING was interrupted before its result was recorded (crash, killed process, restarted Mastra
 * server). Its allowed files were clean at the start (the gate guarantees it), so restoring them is exact and safe.
 * History is kept; the task is NOT silently re-run (see requeueAfterInfraFailure for the one explicit retry).
 */
export async function recoverInterruptedTasks(root: string, state: BatchState): Promise<string[]> {
  const recovered: string[] = [];
  for (const t of state.tasks.filter((x) => x.status === 'RUNNING')) {
    if (t.request) await restoreWorkingTree(state.repository, t.request.contract.allowedFiles);
    t.status = 'RUNTIME_FAILURE';
    t.statusReason = 'interrupted before a result was recorded (batch resumed); allowed files restored';
    const last = t.delegations.at(-1);
    if (last && !last.error) last.error = 'interrupted: no result recorded';
    await logEvent(root, state.batchId, { taskId: t.id, to: t.status, reason: t.statusReason });
    recovered.push(t.id);
  }
  return recovered;
}

/** Applies recovery to a persisted batch (CLI: `recover`). */
export async function recoverBatch(root: string, batchId: string): Promise<BatchState> {
  const state = await loadBatch(root, batchId);
  await recoverInterruptedTasks(root, state);
  await saveBatch(root, state);
  return state;
}

/**
 * An infrastructure failure (no coding evidence: zero coding attempts) is not a failed task. It may be re-queued ONCE per
 * task, and the aborted delegation no longer consumes a delegation slot. A task that actually coded and failed
 * is never re-queued here: that needs a corrected contract (addCorrection).
 */
export async function requeueAfterInfraFailure(root: string, batchId: string, taskId: string, reason: string): Promise<BatchState> {
  if (!reason.trim()) throw new Error('record why the re-queue is safe');
  const state = await loadBatch(root, batchId);
  const task = byId(state, taskId);
  if (task.status !== 'RUNTIME_FAILURE') throw new Error(`${taskId} is ${task.status}; only RUNTIME_FAILURE tasks can be re-queued`);
  const last = task.delegations.at(-1);
  if (!last || last.codingAttempts > 0 || last.engineeringStatus === 'ESCALATED_TO_CLAUDE') {
    throw new Error(`${taskId} has coding evidence (${last?.codingAttempts ?? 0} attempt(s)); a re-queue would repeat a coding failure. Use a correction instead.`);
  }
  if (task.delegations.filter((d) => d.requeued).length >= 1) throw new Error(`${taskId} was already re-queued once after an infrastructure failure`);
  last.requeued = true;
  state.delegatedCount = Math.max(0, state.delegatedCount - 1);
  task.status = 'PENDING';
  task.statusReason = `re-queued after infrastructure failure: ${reason}`;
  for (const t of state.tasks) if (t.status === 'BLOCKED_BY_DEPENDENCY') { t.status = 'PENDING'; t.statusReason = undefined; }
  propagateBlocked(state);
  if (state.state === 'STOPPED' && /infrastructure|runtime failure/.test(state.stopReason ?? '')) { state.state = 'READY'; delete state.stopReason; }
  refreshBatchState(state);
  await logEvent(root, batchId, { taskId, to: 'PENDING', requeued: true, reason });
  await saveBatch(root, state);
  return state;
}

/** The Lead stops a batch on purpose (e.g. another agent owns the same work). Nothing is deleted; history is kept. */
export async function stopBatch(root: string, batchId: string, reason: string): Promise<BatchState> {
  if (!reason.trim()) throw new Error('record why the batch is stopped');
  const state = await loadBatch(root, batchId);
  state.state = 'STOPPED';
  state.stopReason = reason;
  await logEvent(root, batchId, { batch: 'STOPPED', reason });
  await saveBatch(root, state);
  return state;
}

// ---- the loop -------------------------------------------------------------------------

function applyOutcome(task: TaskState, outcome: DelegationOutcome, record: DelegationRecord): void {
  record.runId = outcome.runId ?? record.runId; // never clobber the id persisted at run start
  record.studioUrl = outcome.studioUrl ?? record.studioUrl;
  const r = outcome.result;
  if (!r) {
    record.error = outcome.error ?? 'workflow returned no result';
    task.status = 'RUNTIME_FAILURE';
    task.statusReason = `workflow run did not complete: ${record.error}`;
    return;
  }
  record.engineeringStatus = r.status;
  record.codingAttempts = r.codingAttempts;
  record.runtimeRetries = r.runtimeRetries;
  record.artifactDir = r.artifactDir;
  record.verifier = r.verifier ?? null;
  record.reasons = r.reasons;
}

export interface RunBatchResult {
  state: BatchState;
  /** Task ids that ran this invocation. */
  ran: string[];
}

/**
 * Runs every ready task, one at a time, until none is ready (or the batch stops). A task that reaches WORKER_PASS
 * waits for the Lead's review; independent tasks still proceed, dependents wait. Safe to call again after a crash.
 */
export async function runBatch(root: string, batchId: string, deps: BatchDeps): Promise<RunBatchResult> {
  const state = await loadBatch(root, batchId);
  const log = deps.log ?? (() => {});
  const ran: string[] = [];
  const persist = () => saveBatch(root, state);

  if (state.state === 'STOPPED') {
    log(`batch ${batchId} is STOPPED (${state.stopReason}); not running`);
    return { state, ran };
  }

  await recoverInterruptedTasks(root, state);

  for (const id of propagateBlocked(state)) await logEvent(root, batchId, { taskId: id, to: 'BLOCKED_BY_DEPENDENCY', reason: byId(state, id).statusReason });
  await persist();

  while (state.state !== 'STOPPED') {
    const task = state.tasks.find((t) => isReady(state, t));
    if (!task) break;
    if (state.delegatedCount >= state.maxDelegated) {
      state.state = 'STOPPED';
      state.stopReason = `delegation limit of ${state.maxDelegated} per batch reached`;
      break;
    }

    // Deterministic gate first (reuses routeTask); a refusal never starts a Mastra run.
    const route = await routeTask(task.request as DelegationRequest, state.repository);
    if (route.route === 'claude') {
      task.status = 'KEPT_BY_CLAUDE';
      task.statusReason = `routing gate: ${route.reasons.join('; ')}`;
      await logEvent(root, batchId, { taskId: task.id, to: task.status, reason: task.statusReason });
      for (const bid of propagateBlocked(state)) await logEvent(root, batchId, { taskId: bid, to: 'BLOCKED_BY_DEPENDENCY' });
      await persist();
      continue;
    }

    task.statusBefore = await gitStatusEntries(state.repository);
    task.status = 'RUNNING';
    state.delegatedCount += 1;
    const record: DelegationRecord = { n: task.delegations.length + 1, startedAt: (deps.now?.() ?? new Date()).toISOString(), codingAttempts: 0, runtimeRetries: 0, durationMs: 0, reasons: [] };
    task.delegations.push(record);
    await logEvent(root, batchId, { taskId: task.id, to: 'RUNNING', delegation: record.n });
    await persist();
    log(`[${task.id}] delegating to Qwen via coding-task-workflow`);

    const started = Date.now();
    let outcome: DelegationOutcome;
    try {
      outcome = await deps.delegate(task.request as DelegationRequest, state.repository, {
        async onStart(info) {
          record.runId = info.runId;
          record.studioUrl = info.studioUrl;
          await logEvent(root, batchId, { taskId: task.id, runId: info.runId, started: true });
          await persist();
        },
      });
    } catch (err) {
      outcome = { error: (err as Error).message };
    }
    record.durationMs = Date.now() - started;
    record.finishedAt = (deps.now?.() ?? new Date()).toISOString();
    applyOutcome(task, outcome, record);
    ran.push(task.id);

    if (outcome.result) {
      switch (outcome.result.status) {
        case 'PASS': {
          const inspection = await inspectChange({ repoRoot: state.repository, allowedFiles: task.request!.contract.allowedFiles, statusBefore: task.statusBefore ?? [] });
          task.findings = inspection.findings;
          task.diff = inspection.diff;
          const blocking = inspection.findings.filter((f) => f.severity === 'block');
          if (blocking.length > 0) {
            // Validation failed: preserve the original file, never leave the rejected change in the tree. Only the worker's
            // own allowed files are restored: in a shared work tree an out-of-scope path cannot be attributed to the worker
            // (another agent, a zombie run) and reverting it could destroy someone else's work. It is reported instead.
            await restoreWorkingTree(state.repository, task.request!.contract.allowedFiles);
            task.status = 'REVIEW_REJECTED';
            task.statusReason = `automatic quality gate: ${blocking.map((f) => `${f.code}: ${f.detail}`).join(' | ')}`;
            const unsafe = blocking.some((f) => f.code === 'out_of_scope_file' || f.code === 'security_block');
            if (unsafe) {
              state.state = 'STOPPED';
              state.stopReason = `unsafe change from ${task.id}: ${task.statusReason}`;
            }
          } else {
            task.status = 'WORKER_PASS';
            task.implementedBy = 'qwen';
            task.statusReason = 'harness verifier passed; deterministic review clean; awaiting Lead review';
          }
          break;
        }
        case 'ESCALATED_TO_CLAUDE':
          task.status = 'ESCALATED_TO_CLAUDE';
          task.statusReason = outcome.result.reasons.join('; ');
          if (outcome.result.reasons.includes('forbidden_mutation')) {
            state.state = 'STOPPED';
            state.stopReason = `forbidden mutation by the worker on ${task.id}`;
          }
          break;
        case 'RUNTIME_FAILURE':
          task.status = 'RUNTIME_FAILURE';
          task.statusReason = outcome.result.reasons.join('; ');
          state.state = 'STOPPED';
          state.stopReason = `model runtime failure on ${task.id} (infrastructure)`;
          break;
        default:
          task.status = 'KEPT_BY_CLAUDE';
          task.statusReason = outcome.result.reasons.join('; ');
      }
    } else {
      state.state = 'STOPPED';
      state.stopReason = `workflow infrastructure failure on ${task.id}: ${record.error}`;
    }

    await logEvent(root, batchId, { taskId: task.id, to: task.status, reason: task.statusReason, runId: record.runId, codingAttempts: record.codingAttempts });
    for (const bid of propagateBlocked(state)) await logEvent(root, batchId, { taskId: bid, to: 'BLOCKED_BY_DEPENDENCY' });
    await persist();
  }

  refreshBatchState(state);
  await persist();
  return { state, ran };
}

export function refreshBatchState(state: BatchState): void {
  if (state.state === 'STOPPED') return;
  const awaiting = state.tasks.some((t) => t.status === 'WORKER_PASS');
  const open = state.tasks.some((t) => t.status === 'PENDING' || t.status === 'RUNNING' || t.status === 'KEPT_BY_CLAUDE');
  if (awaiting) state.state = 'AWAITING_REVIEW';
  else if (open) state.state = 'READY';
  else state.state = state.integration && !state.integration.ok ? 'VERIFICATION_FAILED' : 'COMPLETE';
}

// ---- review ------------------------------------------------------------------------------

/** The Lead's decision on a WORKER_PASS diff. Reject restores the working tree so the original files are preserved. */
export async function reviewTask(root: string, batchId: string, taskId: string, decision: 'accept' | 'reject', reason: string, by = 'claude-engineering-lead'): Promise<BatchState> {
  if (!reason.trim()) throw new Error('a review decision must record a reason');
  const state = await loadBatch(root, batchId);
  const task = byId(state, taskId);
  if (!task) throw new Error(`unknown task ${taskId}`);
  if (task.status !== 'WORKER_PASS') throw new Error(`${taskId} is ${task.status}; only WORKER_PASS tasks can be reviewed`);
  task.review = { decision, reason, by, at: new Date().toISOString() };
  if (decision === 'accept') {
    task.status = 'ACCEPTED';
    task.statusReason = `accepted by ${by}: ${reason}`;
  } else {
    await restoreWorkingTree(state.repository, task.request!.contract.allowedFiles);
    task.status = 'REVIEW_REJECTED';
    task.statusReason = `rejected by ${by}: ${reason}`;
  }
  propagateBlocked(state);
  refreshBatchState(state);
  await logEvent(root, batchId, { taskId, to: task.status, reason: task.statusReason });
  await saveBatch(root, state);
  return state;
}

/**
 * One narrowly scoped correction per rejected task, and only with a reason and a contract that actually differs:
 * the same failed task is never re-delegated unchanged.
 */
export async function addCorrection(root: string, batchId: string, rejectedId: string, correction: BatchTaskPlan, reason: string): Promise<BatchState> {
  const state = await loadBatch(root, batchId);
  const rejected = byId(state, rejectedId);
  if (rejected.status !== 'REVIEW_REJECTED' && rejected.status !== 'ESCALATED_TO_CLAUDE') throw new Error(`${rejectedId} is ${rejected.status}; only rejected/escalated tasks take a correction`);
  if (rejected.supersededBy) throw new Error(`${rejectedId} already has a correction (${rejected.supersededBy})`);
  if (!reason.trim()) throw new Error('a correction must record why it differs');
  const parsed = batchTaskSchema.parse({ ...correction, correctionOf: rejectedId, dependsOn: correction.dependsOn ?? rejected.dependsOn });
  if (parsed.executor === 'qwen' && JSON.stringify(parsed.request) === JSON.stringify(rejected.request)) {
    throw new Error('the correction contract is identical to the failed one; change the contract or keep the task with Claude');
  }
  if (state.tasks.some((t) => t.id === parsed.id)) throw new Error(`duplicate task id ${parsed.id}`);
  state.tasks.push({
    ...parsed,
    status: parsed.executor === 'claude' ? 'KEPT_BY_CLAUDE' : 'PENDING',
    statusReason: parsed.executor === 'claude' ? parsed.keptReason : `correction of ${rejectedId}: ${reason}`,
    delegations: [],
    findings: [],
  });
  rejected.supersededBy = parsed.id;
  // Dependents blocked only because of the rejected task are re-evaluated against its correction.
  for (const t of state.tasks) if (t.status === 'BLOCKED_BY_DEPENDENCY') { t.status = 'PENDING'; t.statusReason = undefined; }
  propagateBlocked(state);
  if (state.state === 'STOPPED' && !state.stopReason?.startsWith('unsafe')) state.state = 'READY';
  await logEvent(root, batchId, { taskId: parsed.id, to: 'PENDING', correctionOf: rejectedId, reason });
  await saveBatch(root, state);
  return state;
}

/** The Lead records that it implemented (or otherwise finished) a task it kept; it still needs its own reason. */
export async function completeClaudeTask(root: string, batchId: string, taskId: string, note: string): Promise<BatchState> {
  if (!note.trim()) throw new Error('record what was done and why Claude did it');
  const state = await loadBatch(root, batchId);
  const task = byId(state, taskId);
  if (task.status !== 'KEPT_BY_CLAUDE') throw new Error(`${taskId} is ${task.status}`);
  task.status = 'ACCEPTED';
  task.implementedBy = 'claude';
  task.review = { decision: 'accept', reason: note, by: 'claude-engineering-lead', at: new Date().toISOString() };
  task.statusReason = `implemented by Claude: ${note}`;
  refreshBatchState(state);
  await logEvent(root, batchId, { taskId, to: 'ACCEPTED', implementedBy: 'claude', reason: note });
  await saveBatch(root, state);
  return state;
}

// ---- integration verification -----------------------------------------------------------

/** Materializes the accepted tasks' harness-owned oracles as permanent test files (uncommitted, for the Lead to keep). */
export async function materializeOracles(root: string, batchId: string): Promise<string[]> {
  const state = await loadBatch(root, batchId);
  const written: string[] = [];
  for (const t of state.tasks.filter((x) => x.status === 'ACCEPTED' && x.request)) {
    for (const [path, content] of Object.entries(t.request!.contract.hiddenFiles ?? {})) {
      const target = join(state.repository, path.replace(/\.hidden\.test\.js$/, '.test.js'));
      await mkdir(join(target, '..'), { recursive: true });
      await writeFile(target, content);
      written.push(target.slice(state.repository.length + 1));
    }
  }
  return written;
}

export async function runIntegration(root: string, batchId: string): Promise<BatchState> {
  const state = await loadBatch(root, batchId);
  const open = state.tasks.filter((t) => t.status === 'PENDING' || t.status === 'RUNNING' || t.status === 'WORKER_PASS');
  if (open.length > 0) throw new Error(`integration verification needs every task decided; open: ${open.map((t) => t.id).join(', ')}`);
  const results: NonNullable<BatchState['integration']>['results'] = [];
  for (const command of state.integrationCommands) {
    if (command[0] === 'npx') {
      const problems = await validateJsVerification(command, { taskId: 'integration', objective: 'integration', allowedFiles: [], contextFiles: [], acceptanceCriteria: [], verificationCommands: [command], constraints: [], hiddenFiles: {} }, state.repository);
      if (problems.length > 0) throw new Error(`integration command rejected: ${problems.join('; ')}`);
    }
    const r = await runControlledCommand(command[0], command.slice(1), { cwd: state.repository, timeoutMs: 600_000 });
    results.push({ command, exitCode: r.exitCode, output: `${r.stdout}${r.stderr}`.trim().slice(-1500) });
    if (!r.success) break;
  }
  const ok = results.length === state.integrationCommands.length && results.every((r) => r.exitCode === 0);
  state.integration = { ok, at: new Date().toISOString(), results };
  state.state = 'READY';
  refreshBatchState(state);
  if (!ok) state.state = 'VERIFICATION_FAILED';
  await logEvent(root, batchId, { integration: ok ? 'ok' : 'failed' });
  await saveBatch(root, state);
  return state;
}

// ---- reporting ----------------------------------------------------------------------------

export interface BatchSummary {
  planned: number;
  plannedForQwen: number;
  delegatedToQwen: number;
  completedByQwen: number; // ACCEPTED, implemented by qwen
  keptByClaude: number;
  keptByClaudeAccepted: number;
  failedOrEscalated: number;
  totalCodingAttempts: number;
  totalDelegations: number;
  runIds: string[];
  /** accepted Qwen implementation tasks / all accepted implementation tasks (planning/review tasks never count). */
  localWorkerImplementationRate: number | null;
  byStatus: Record<string, number>;
}

export function summarizeBatch(state: BatchState): BatchSummary {
  const impl = state.tasks.filter((t) => t.kind === 'implementation');
  const acceptedImpl = impl.filter((t) => t.status === 'ACCEPTED');
  const qwenAccepted = acceptedImpl.filter((t) => t.implementedBy === 'qwen');
  const byStatus: Record<string, number> = {};
  for (const t of state.tasks) byStatus[t.status] = (byStatus[t.status] ?? 0) + 1;
  return {
    planned: state.tasks.length,
    plannedForQwen: state.tasks.filter((t) => t.executor === 'qwen').length,
    delegatedToQwen: state.tasks.filter((t) => t.delegations.length > 0).length,
    completedByQwen: qwenAccepted.length,
    keptByClaude: state.tasks.filter((t) => t.executor === 'claude' || t.statusReason?.startsWith('routing gate')).length,
    keptByClaudeAccepted: acceptedImpl.filter((t) => t.implementedBy === 'claude').length,
    failedOrEscalated: state.tasks.filter((t) => FAILED_STATUSES.includes(t.status) && t.status !== 'BLOCKED_BY_DEPENDENCY').length,
    totalCodingAttempts: state.tasks.reduce((n, t) => n + t.delegations.reduce((m, d) => m + d.codingAttempts, 0), 0),
    totalDelegations: state.tasks.reduce((n, t) => n + t.delegations.length, 0),
    runIds: state.tasks.flatMap((t) => t.delegations.map((d) => d.runId).filter((x): x is string => Boolean(x))),
    localWorkerImplementationRate: acceptedImpl.length === 0 ? null : qwenAccepted.length / acceptedImpl.length,
    byStatus,
  };
}
